package com.koi.FA24_SE1854_SWP391_G6_KoiCareHome.exception;

public class AlreadyExistedException extends RuntimeException {
    public AlreadyExistedException(String message) {
        super(message);
    }
}
