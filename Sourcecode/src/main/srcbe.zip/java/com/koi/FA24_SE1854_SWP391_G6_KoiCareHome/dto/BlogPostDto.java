package com.koi.FA24_SE1854_SWP391_G6_KoiCareHome.dto;

import lombok.Data;

@Data
public class BlogPostDto {
    private String title;
    private String author;
}
