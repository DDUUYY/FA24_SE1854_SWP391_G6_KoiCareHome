
const NotFound = () => {
  return (
    <div className="container">
      <h1>404 Not Found</h1>
      <p>Error Stuff.</p>
    </div>
  );
};

export default NotFound;