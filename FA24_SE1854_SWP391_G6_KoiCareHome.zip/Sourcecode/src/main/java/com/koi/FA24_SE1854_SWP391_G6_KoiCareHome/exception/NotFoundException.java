package com.koi.FA24_SE1854_SWP391_G6_KoiCareHome.exception;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String message) {
        super(message);
    }
}
