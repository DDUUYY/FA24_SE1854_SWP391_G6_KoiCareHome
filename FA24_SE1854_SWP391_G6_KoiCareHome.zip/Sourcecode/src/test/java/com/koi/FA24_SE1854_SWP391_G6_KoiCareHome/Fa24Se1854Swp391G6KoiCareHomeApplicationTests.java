package com.koi.FA24_SE1854_SWP391_G6_KoiCareHome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Fa24Se1854Swp391G6KoiCareHomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
