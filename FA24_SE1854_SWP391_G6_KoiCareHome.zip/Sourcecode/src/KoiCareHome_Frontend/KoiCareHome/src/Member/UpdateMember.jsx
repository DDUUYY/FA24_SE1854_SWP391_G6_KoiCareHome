import './UpdateMember.css';
import { useEffect, useState } from "react";
import { useNavigate, useParams } from 'react-router-dom';

/*
 * Author: Ha Huy Nghia Hiep
 * Date: October 19, 2024
 */

const UpdateMember = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: "",
    oldPassword: "",
    newPassword: "",
    confirmNewPassword: ""
  });

  const [error, setError] = useState("");

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  useEffect(() => {
    const fetchMember = async () => {
      try {
        const response = await fetch(`http://localhost:8080/api/Member/${id}`);
        const data = await response.json();
        setFormData({
          ...data,
          oldPassword: "",
          newPassword: "",
          confirmNewPassword: ""
        });
      } catch (error) {
        console.error("Error fetching member data:", error.message);
      }
    };

    fetchMember();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { firstName, lastName, email, phoneNumber, newPassword, confirmNewPassword } = formData;

    
    if (!firstName || !lastName || !email || !phoneNumber) {
      setError("Please fill in all required fields.");
      return;
    }

    // Validate phone number format (10 digits)
    if (!/^0(3|5|7|8|9)\d{8}$/.test(phoneNumber)) {
      setError("Phone number must be a valid Vietnamese number (10 digits).");
      return;
    }

    // Validate new password (if provided)
    if (newPassword && !/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{7,}$/.test(newPassword)) {
      setError("New password must be at least 7 characters long, containing at least one letter and one number.");
      return;
    }

    // Check if new passwords match
    if (newPassword && newPassword !== confirmNewPassword) {
      setError("New passwords do not match.");
      return;
    }

    try {
      const updatePayload = {
        firstName,
        lastName,
        email,
        phoneNumber
      };

      // Include new password only if provided
      if (newPassword) {
        updatePayload.password = newPassword;
      }

      const response = await fetch(`http://localhost:8080/api/Member/${id}`, {
        method: 'PATCH',
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatePayload),
      });

      if (response.ok) {
        const data = await response.json();
        console.log("Member updated:", data);
        navigate(`/profile`);
      } else {
        setError("Error updating member.");
      }
    } catch (error) {
      setError("Error updating member: " + error.message);
    }
  };

  const handleBack = () => {
    navigate(`/profile`);
  };

  return (
    <div className="update-member-form-container">
      <h1 className="update-member-title">Change your information</h1>
      {error && <p className="update-member-error">{error}</p>}
      <form onSubmit={handleSubmit} className="update-member-form">
        <input
          type="text"
          name="firstName"
          placeholder="First Name"
          value={formData.firstName}
          onChange={handleInputChange}
          className="update-member-input"
          required
        />
        <input
          type="text"
          name="lastName"
          placeholder="Last Name"
          value={formData.lastName}
          onChange={handleInputChange}
          className="update-member-input"
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={formData.email}
          onChange={handleInputChange}
          className="update-member-input"
          required
        />
        <input
          type="text"
          name="phoneNumber"
          placeholder="Phone Number"
          value={formData.phoneNumber}
          onChange={handleInputChange}
          className="update-member-input"
          required
        />
        <input
          type="password"
          name="newPassword"
          placeholder="New Password"
          value={formData.newPassword}
          onChange={handleInputChange}
          className="update-member-input"
        />
        <input
          type="password"
          name="confirmNewPassword"
          placeholder="Confirm New Password"
          value={formData.confirmNewPassword}
          onChange={handleInputChange}
          className="update-member-input"
        />
        <button type="submit" className="update-member-submit-btn">Confirm</button>
        <button type="button" className="back-button" onClick={handleBack}>Back</button>
      </form>
    </div>
  );
};

export default UpdateMember;